//
// Created by bergolho on 12/02/19.
//

#ifndef TEST_H
#define TEST_H

#include <cstdio>
#include <cstdlib>
#include <cstdbool>
#include <cstdint>

class CCO_Network;

void test1 (CCO_Network *the_network);

#endif